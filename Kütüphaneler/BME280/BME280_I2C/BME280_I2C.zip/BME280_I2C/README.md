# BME280_I2C
BME280 Tempreture, Humidity and Pressure Sensor Arduino Library (Sıcaklık, Nem ve Basınç Sensörü Kütüphanesi)

I2C Üzerinden (SDA, SCL) BME280 Sensörünün Kütüphanesini içerir.
